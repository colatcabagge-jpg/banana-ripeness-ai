CVLab – IEEE Submission Package
================================

Generated on: 2026-02-01 14:14:07

Contents:
- figures/: All IEEE-ready figures (auto-generated)
- tables/: Experiment comparison tables
- captions/: Figure & table captions
- methodology.md: Auto-generated methodology
- results.md: Auto-generated results
- dev_journal.md: Human-readable experiment log
- journal_events.json: Machine-readable event log
- model_registry.json: Model registry snapshot

This package was generated automatically by CVLab.
No manual edits were performed.